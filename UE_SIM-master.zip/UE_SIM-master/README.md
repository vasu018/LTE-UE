# UE_SIM
An LTE UE packet generator module which can generate LTE attach packets and handle replies parallelly.

To build ->
```
$make
```

Usage:
./ue <number of ue> <IMSI seed (Default = 0)>

