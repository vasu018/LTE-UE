#!/bin/bash

#attach for new x and service for earlier x

./ue 0 5000 1 5001 &
./ue 1 5000 1 1 &

