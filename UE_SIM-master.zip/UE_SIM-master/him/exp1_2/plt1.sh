#!/bin/bash

#attach for new x and service for earlier x

./ue 0 1 30000 1 30001&
./ue 1 1 30000 1 1

