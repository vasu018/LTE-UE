./ue 0 10000 1 4
sh ./service_bg.sh $1 1 &
./ue 1 10000 1 4
